'''
Write a Python program to display all the files and folders separately and its count also.
files
------
file1
file2
Total no. of files : 504

directories
------------
dir1
Total no. of direcotires : 453'
'''
import os
filelist  = list()
dirlist = list()
try:
    files= os.listdir()
    for file in files:
        if os.path.isfile(file):
            filelist.append(file)
        elif os.path.isdir(file):
            dirlist.append(file)

    # display
    for file in filelist:
        print(file)
    print("total no. of files :", len(filelist))
    # for directories
    for file in dirlist:
          print(file)
    print("total. no. of directories :", len(dirlist))

except Exception as err:
    print(err)












