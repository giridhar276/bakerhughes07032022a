
#write a program to delete all .csv files from the current directory

import os
#os.remove("IPL.csv")

try:
    for file in os.listdir():
        if file.endswith(".csv"):
            #print(file)
            os.remove(file)
except Exception as err:
    print(err)



import os
files = []
for file in os.listdir():
    if file.endswith(".csv"):
        files.append(file)

deletefiles = lambda x : os.remove(x)

for file in files:
    deletefiles(file)
