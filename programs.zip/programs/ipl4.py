'''
write a program to display the country and the no. of players representing that country with proper exception handling
SA - 16 players
IND - 45 players
..
..
'''
import csv
countrylist = list()
try:
    with open("IPL.csv","r") as fobj:
        header = fobj.readline()
        #converting file object to csv object
        reader = csv.reader(fobj)
        for line in reader:
            #processing
            country = line[3]
            countrylist.append(country)
        #displaying
        for country in set(countrylist):
            print(country.ljust(10) , countrylist.count(country),"players" )
except FileNotFoundError as err:
    print(err)
except Exception as err:
    print(err)
