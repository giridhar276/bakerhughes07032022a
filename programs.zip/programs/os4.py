'''
create 2 folders named as below

source   folder ( copy few files to source folder)
destination folder 

write a program to copy all the files from source to destination'
'''

import shutil
import os
import sys
source = r"C:\Users\gsripath\Desktop\programs\source"
destination = r"C:\Users\gsripath\Desktop\programs\destination"
os.chdir(source)
try:

    for file in os.listdir():
        #print(file)
        shutil.copy(file,destination)
except Exception as err:
    print(err)
    print(sys.exc_info())
