
# keyword args

def display(b,c,a):
    print(a,b,c)


display(a=10,b=20,c=30)






