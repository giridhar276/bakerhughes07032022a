import pymysql
from openpyxl import Workbook
import csv
import time
import os

wb = Workbook()
# grab the active worksheet
ws = wb.active

db = pymysql.connect(host = "localhost",port=3306,user="root",password="india@123")
#create cursor
cursor = db.cursor()
# define your query
query = "select street,city from acuvate.realestate"
# execute your query
cursor.execute(query)
# fetch your records
for line in cursor.fetchall():
    #print(line)
    ws.append(line)
wb.save("db_xlsx.xlsx")
# close the connection
db.close()

