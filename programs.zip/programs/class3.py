class Employee:
    def displayName(self,name):
        self.name = name
        print("Emp name :", self.name)
    def displayAddress(self,address):
        self.address = address
        print("Emp address  :", self.address)

        
emp1 = Employee()
emp1.displayName("Rita")
emp1.displayAddress("Miyapur,Hyderabad")

emp2 = Employee()
emp2.displayName("Riya")
emp2.displayAddress("MG Road,Delhi")
