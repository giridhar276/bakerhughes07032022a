
"""
#examplec
fobj= open("languages.txt","w")
fobj.write("python programming\n")
fobj.write("scala programming\n")

#closing
fobj.close()
"""

'''
#examplec
fobj= open("C:\\Users\105030170\\WORK\\Trainings\\Python_7mar-11mar_2022\\languages1.txt","w")
fobj.write("python programming\n")
fobj.write("scala programming\n")

#closing
fobj.close()
'''


#numbers
fobj= open("numbers.txt","w")
for i in range(1,100):
    fobj.write(str(i)+"\n")

#closing
fobj.close()
