
x = "Hi"
def change_local_x():
    x = "Bye"
    print(x)     # Bye

change_local_x()
print(x)      



x = "Hi"
def change_global_x():
    global x
    x = "Bye"

    print(x)

change_global_x()
x = "test"
print(x)
