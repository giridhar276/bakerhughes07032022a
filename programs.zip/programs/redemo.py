
import re

with open("example.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("pyt{1,5}hon",line):
            print(line)
