# with constructor
class Employee:
    def __init__(self,name,address):
        #local objects which are accessed within
        # the class and all the methods
        self.name = name
        self.address = address
        
    def displayDetails(self):
        
        print("Emp name :", self.name)
        print("Emp address  :", self.address)

# contructor: constructor will be invoked automatically
# In python constructor starts with __init__ ( builtin)
# when the object is created/called,
# constructor will be invoked automatically
emp1 = Employee("Rita","Miyapur,Hyderabad")
emp1.displayDetails()

emp2 = Employee("Riya","MG Road,Delhi")
emp2.displayDetails()

emp3 = Employee("Riya","MG Road,Delhi")
emp3.displayDetails()
