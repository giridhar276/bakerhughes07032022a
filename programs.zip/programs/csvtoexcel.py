from openpyxl import Workbook
import csv
import time
wb = Workbook()
# grab the active worksheet
ws = wb.active

with open("IPL.csv","r") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        ws.append(line)

filename = time.strftime("%d_%b_%Y.xlsx")
#11_Mar_2022.xlsx
# Save the file
wb.save(filename)





