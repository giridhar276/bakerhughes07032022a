
#list
alist = [10,30,4,34,45]

print(alist[0])

alist[0] = 1000

print('After replacing :', alist)



# tuple
atup = (45,34,32,56)
#atup[0] = 40
print('After replacing :', atup)

# typecasting - converting from one object to another object
alist = list(atup)   # converting tuple to list
alist.append(987)
atup = tuple(alist)  # reconverting back to tuple
print("After changes :", atup)
