#2
# reading the file all at once
with open("lang.txt","r") as fobj:
    print(fobj.read())   # string output


# reading n no. of characters
with open("lang.txt","r") as fobj:
    print(fobj.read(10))   # string output
    
