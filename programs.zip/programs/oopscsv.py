
from openpyxl import Workbook
import csv
import time

class Conversion:
    def __init__(self,csvfile):
        self.csvfile = csvfile

    def convertCSV(self):
        self.wb = Workbook()
        # grab the active worksheet
        self.ws = self.wb.active
    def processToExcel(self):
        with open(self.csvfile,"r") as fobj:
            self.reader = csv.reader(fobj)
            for line in self.reader:
                self.ws.append(line)
        filename = time.strftime("%d_%b_%Y_1.xlsx")
        self.wb.save(filename)

            

excel = Conversion("IPL.csv")
excel.convertCSV()
excel.processToExcel()
