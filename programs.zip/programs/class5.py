
class Employee:
    def getDetails(self,name,address):
        #local objects which are accessed within
        # the class and all the methods
        self.name = name
        self.address = address
        
    def displayDetails(self):
        
        print("Emp name :", self.name)
        print("Emp address  :", self.address)

        
emp1 = Employee()
emp1.getDetails("Rita","Miyapur,Hyderabad")
emp1.displayDetails()

emp2 = Employee()
emp2.getDetails("Riya","MG Road,Delhi")
emp2.displayDetails()
