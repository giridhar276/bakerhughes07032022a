
#write a program to display ONLy .py files from the current directory


import os

try:
    # will display from current working directory
    files = os.listdir()
    for file in files:
        if file.endswith(".csv"):
            print(file)
except Exception as err:
    print(err)


#write a program to display all the files and folders from the D:\
import os

try:
    files = os.listdir("D:\\")
    for file in files:
        print(file)
except Exception as err:
    print(err)    
