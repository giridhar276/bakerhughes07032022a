from openpyxl import Workbook
import csv
import time
import os
def create_excel():
    try:
        wb = Workbook()
        # grab the active worksheet
        ws = wb.active
        csvfile = "IPL.csv"
        if os.path.isfile(csvfile) or os.path.getsize(csvfile) >0:
            with open(csvfile,"r") as fobj:
                reader = csv.reader(fobj)
                for line in reader:
                    ws.append(line)
            #11_Mar_2022.xlsx
            # Save the file
            filename = time.strftime("%d_%b_%Y.xlsx")
            if os.path.exists(filename):
                os.rename(filename,filename+".bak")
            
            wb.save(filename)
        else:
            print(csfile,"file doesn't exist")
    except Exception as err:
        print(err)

# calling function
create_excel()
