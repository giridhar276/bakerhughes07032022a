

import csv
try:
    filename  = input("Enter any filename :")
    with open(filename,"r") as fobj:
        # convert file object to csv object
        reader = csv.reader(fobj)
        for line in reader:
            print(line)
except FileNotFoundError as err:
    print(err)
except ValueError as err:
    print(err)
except TypeError as err:
    print(err)
except (KeyError,IndexError) as err:
    print(err)
except Exception as e:
    print("system error :", e)
    print("user defined error :", "File not found ")
