# fixed arguments
# function definition
def display(a,b):
    c = a + b
    return c
# calling function
total = display(10,20)
print(total)


#lambda function  - inline function, nameless function
#lambda is just the replacement of single liner function
#Instead of giving a call to function definition ... lambda gets replaced in the calling function
#functioname= lambda variables :expression
display = lambda x,y : x + y

# calling function
total = display(10,20)
print(total)


display = lambda *args : sum(args)
# calling function
total = display(10,20,30,40,50,60)
print(total)


##########################
alist = [10,20,30,40]  # input
#Output [15,25,35,45]  # output
##########################
# c style coding # legacy coding # old style code
alist = [10,20,30,40]
blist = []
for val in alist:
    blist.append(val + 5)
print(blist)
##########################
alist = [10,20,30,40]
def increment(x):
    return x + 5
print(list(map(increment, alist)))
##########################
alist = [10,20,30,40]
increment = lambda x : x+5
print(list(map(increment, alist)))
##########################
alist = [10,20,30,40]
print(list(map(lambda x : x+5, alist)))
##########################
alist  = ["python","c","ruby","unix","shell"]   # [ 6,1,4,4,5]
print(list(map(lambda x : len(x), alist)))
############################
alist = ["1","2","4","9"]    # [1,2,4,9]
print(list(map(lambda x : int(x), alist)))




alist = [1,2,3,4,5,6,7]
# [1,3,5,7]
print(list(filter(lambda x : x %2 ==0, alist)))  #[2,4,6]
print(list(filter(lambda x : x %2 , alist)))     #[1,3,5,7]
print(list(filter(lambda x : x %2  != 0, alist))) 

strings = ["unix","c","java","ruby"]
# ["unix","java","ruby"]
print(list(filter(lambda x : len(x) == 4, strings)))















    
