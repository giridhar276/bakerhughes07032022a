class Employee:
    def displayName(self,name):
        print("Employee name: ",name)
    def displayAddress(self,address):
        print("Emp address  :", address)


emp1 = Employee()
emp1.displayName("Rita")
emp1.displayAddress("Miyapur,Hyderabad")



emp2 = Employee()
emp2.displayName("Riya")
emp2.displayAddress("MG Road,Delhi")
