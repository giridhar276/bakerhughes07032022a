
#write a program to display all the files line by line from the current directory with proper exception handling

import os

try:
    files = os.listdir()
    for file in files:
        print(file)
except Exception as err:
    print(err)
