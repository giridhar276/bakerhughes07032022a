


class Employee:
    def displayName(self):
        print("Employee name: ","Rita")
    def displayAddress(self):
        print("Emp address:","Miyapur,Hyderabad")



emp1 = Employee()
emp1.displayName()
emp1.displayAddress()



emp2 = Employee()
emp2.displayName()
emp2.displayAddress()
