print("hello python")

print(list(range(1,10)))
# capture input from keyboard
val = input()
print("Input value is ", val)
# capture input from keyboard with some meaningful text
val = input("Enter some value :")
print("Input value is ", val)

alist = [10,20,5,54,434,54,43]
print(max(alist))
print(min(alist))
print(sum(alist))

# ascii to char
print(chr(97))
#  character or ascii code
print(ord('a'))

name = "python"
print(type(name)) # method1
print(isinstance(name,str))  # True
print(isinstance(name,list))

alist = [10,20,30]
print(type(alist))
print(isinstance(alist,list))  # True
print(isinstance(alist,dict))  # False




















