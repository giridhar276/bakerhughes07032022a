import pdb


"""
print(10,20,30,"helo")

print("python","unix","java")

name = "python programming"
print(name)


print(name.capitalize() )
print(name.upper() )
print(name)
print(name.lower()) 

print(name.count('p') )

print(name.replace("python","shell"))


print(name.endswith("p"))
print(name.endswith("g"))

aname = " python  "
print(len(aname))
print(len(aname.strip()))  # remove whitespaces at both ends
print(len(aname.rstrip()))
print(len(aname.lstrip()))

aname = "apythona"
print(aname.strip('a'))

"""

# string
name = "python programming"
print(name.isupper())

if name.isupper() :
    print("Inside if")
    print("String is upper")
    print("Inside if")
else:
    print("Inside else")
    print("String is lower")
    print("Inside else")
print("regular code")


if name.startswith("p"):
    print("python programming")
elif name.startswith("j"):
    print("java programmin")
elif name.startswith("s"):
    print("scala programming")
else:
    print("Its C programming")

#slicing
#string[start:stop:step]
name = "python programming"
print(name[0]) #p
print(name[1]) #y
print(name[0:7])
print(name[7:10])
print(name[::])
print(name[:])
print(name[0:18:2])
print(name[1:18:2])
print(name[4:18:4])
print(name[-1])
print(name[-2])
print(name[-5:-2])
print(name[::-1])
print(name[::-2])


# for loop
#range(start,stop,step)
for val in range(1,11):
    print(val)
for val in range(1,11,2):
    print(val)    
for val in range(11,1,-1):
    print(val)

name = "python"
for char in name:
    print(char)


name = "python programming language and unix shell scripting and perl"
output = name.split(" ")
for char in output:
    #print(char)
    if len(char) == 4 :
        print(char)
    

















    
    












