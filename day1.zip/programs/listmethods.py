alist =[45,34,65,43,2,78,54]

print(alist)
print("Total no. of elements :", len(alist))

# list.append()  --> add single object to the end of the list
alist.append(650)
print('After appending :', alist)
alist.append(98)
print('After appending :', alist)

##list.extend() --> adding multiple values
alist.extend([12,3,55] )
print('After extending :', alist)

# list.insert(index,value)  --> adding at the index position
alist.insert(2,200)
print('After inserting :', alist)

# list.pop(index)  --> value at that index position will be removed
alist.pop(1)
print("After pop :", alist)

# list.remove(value)  --> value will be removed directly
alist.remove(54)   # 54 is the value
print("After removing :", alist)

#alist.remove(54)   # 54 is the value
#print("After removing :", alist)

if 54 in alist :
    alist.remove(54)
else:
    print(54,"doesn't exist")

getcount = alist.count(54)
if getcount > 0 :
    alist.remove(54)
else:
    print(54,"doesn't exist")

print(alist)
## list.reverse()
alist.reverse()
print("After reversing :", alist)

# list.sort()
alist.sort()  # ascending order
print("Ascending order:", alist)

alist.sort(reverse = True)
print("Ascending order:", alist)






alist = [12,4.3,"hello",45,43,56,43,56]

for val in alist:
    if isinstance(val,int):
        print(val, " is integer")
    elif isinstance(val,str):
        print(val," is string")
    elif isinstance(val,float):
        print(val,"is decimal")

































