


adict = {'chap1': 10, 'chap2': 20, 'chap3': 30, 'chap4': 40}

print(adict)
# display Keys
for key in adict.keys():
    print(key)


# display keys
for key in adict:
    print(key)


# display values
for value in adict.values():
    print(value)

# display key:value at a time
for key,value in adict.items():
    if key in ["chap1","chap2"]:
        print(key,value)
