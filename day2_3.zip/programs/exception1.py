

import csv
try:
    filename  = input("Enter any filename :")
    with open(filename,"r") as fobj:
        # convert file object to csv object
        reader = csv.reader(fobj)
        for line in reader:
            print(line)
    # 2nd logic
    book = {"chap1":10 ,"chap2":20}
    print(book["chap100"])
except Exception as e:
    print("system error :", e)
    print("user defined error :", "File not found ")
