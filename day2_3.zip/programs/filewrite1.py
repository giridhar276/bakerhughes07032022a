
# current working directory
# opening the file in write mode
fobj = open("languages.txt","w")
# writing
fobj.write("python programming\n")
fobj.write("scala programming\n")
# closing
fobj.close()


# file in different path
# opening the file in write mode
#fobj = open("D:/trainings/edyoda07022022a/languages.txt","w")  # or # 
#fobj = open(r"D:\trainings\edyoda07022022a\languages.txt","w") # or  #raw
fobj = open("D:\\trainings\\edyoda07022022a\\languages.txt","w")
# writing
fobj.write("python programming\n")
fobj.write("scala programming\n")
# closing
fobj.close()


fobj  = open("numbers.txt","w")
for val in range(1,100):
    fobj.write(str(val) +  "\n")
fobj.close()
