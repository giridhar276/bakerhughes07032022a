

def display1(b,c,a):
    print(a,b,c)


def display2(b,c,a):
    print(a,b,c)


def display3(b,c,a):
    print(a,b,c)


def display4(b,c,a):
    print(a,b,c)



def display5(b,c,a):
    print(a,b,c)
