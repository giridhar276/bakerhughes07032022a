
# modern style
# pythonic way
# context manager
# if any line starts with keyword 'with'  it is called as context manager
# Advantage : File will be closed automatically
# fobj acts as file reference of file handler or file pointer
with open("lang.txt","r") as fobj:
    for line in fobj:   # always checks for EOF
        # remove whitespaces if any
        line = line.strip()
        print(line)

